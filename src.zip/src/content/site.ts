// Non-translatable data. All visible text lives in /messages/<locale>.json.

export const SITE_URL = "https://charlesbouvier.dev";

export const contact = {
  email: "charlesbouvier832@hotmail.com",
  github: "https://github.com/lignix",
  linkedin: "https://linkedin.com/in/charles-bouvier/",
};

export const cv: Record<string, string | null> = {
  en: null,
  fr: "/cv_fr.pdf",
};

export type ProjectLink = {
  kind: "steam" | "repo" | "demo";
  href: string;
};

export type ProjectId = "marketplace" | "yatai8" | "jlptAnalyzer";

// TODO: add your links, e.g. { kind: "steam", href: "https://store.steampowered.com/app/..." }
export const projects: { id: ProjectId; stack: string[]; links: ProjectLink[] }[] = [
  { id: "marketplace", stack: ["Spring Boot", "React", "Microservices"], links: [] },
  { id: "yatai8", stack: ["Unity", "C#"], links: [] },
  { id: "jlptAnalyzer", stack: ["TypeScript"], links: [] },
];

export const experience = {
  dev: ["wolters", "phraser"],
  other: ["sncf", "leroy"],
} as const;

export const skills = {
  frontend: ["React", "Next.js", "TypeScript", "JavaScript", "Tailwind CSS", "HTML/CSS"],
  backend: ["Java", "C#", "Node.js", "PHP", "SQL"],
  methods: ["OOP", "MVC", "Agile (Scrum)"],
  tools: ["Git", "VS Code", "IntelliJ", "Figma", "Notion", "Linear"],
} as const;
