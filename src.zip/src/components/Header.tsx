import { useTranslations } from "next-intl";
import { LanguageSwitcher } from "./LanguageSwitcher";

const links = ["projects", "experience", "skills", "contact"] as const;

export function Header() {
  const t = useTranslations("nav");
  const common = useTranslations("common");

  return (
    <header className="mx-auto flex w-full max-w-5xl flex-wrap items-center justify-between gap-x-6 gap-y-4 px-6 py-6 md:px-10">
      <a href="#main" className="font-display text-lg font-semibold tracking-tight">
        Charles Bouvier
      </a>
      <LanguageSwitcher />
      <nav
        aria-label={common("mainNavigation")}
        className="order-last w-full md:order-none md:w-auto"
      >
        <ul className="flex flex-wrap gap-x-6 gap-y-2 font-display text-sm font-medium">
          {links.map((key) => (
            <li key={key}>
              <a href={`#${key}`} className="text-muted hover:text-ink">
                {t(key)}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </header>
  );
}
