import { useTranslations } from "next-intl";
import { projects } from "@/content/site";
import { Section } from "./Section";

export function Projects() {
  const t = useTranslations("projects");

  return (
    <Section id="projects" title={t("title")}>
      <ul className="divide-y divide-line border-y border-line">
        {projects.map((project) => (
          <li key={project.id} className="py-8 first:pt-6 last:pb-6">
            <h3 className="font-display text-xl font-semibold tracking-tight">
              {t(`items.${project.id}.title`)}
            </h3>
            <p className="mt-2 max-w-[60ch] text-pretty text-muted">
              {t(`items.${project.id}.description`)}
            </p>

            <ul
              aria-label={t("stack")}
              className="mt-4 flex flex-wrap gap-x-5 gap-y-1 font-display text-sm font-medium"
            >
              {project.stack.map((tech) => (
                <li key={tech}>{tech}</li>
              ))}
            </ul>

            {project.links.length > 0 && (
              <ul className="mt-4 flex flex-wrap gap-x-6 gap-y-2 font-display text-sm font-semibold">
                {project.links.map((link) => (
                  <li key={link.kind}>
                    <a
                      href={link.href}
                      className="text-accent underline"
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      {t(`links.${link.kind}`)}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </li>
        ))}
      </ul>
    </Section>
  );
}
