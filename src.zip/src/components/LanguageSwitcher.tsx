"use client";

import { useLocale, useTranslations } from "next-intl";
import { Link, usePathname } from "@/i18n/navigation";
import { routing } from "@/i18n/routing";

// Labels shown in the switcher. Add one when you add a locale.
const labels: Record<string, string> = {
  en: "English",
  fr: "Français",
};

export function LanguageSwitcher() {
  const locale = useLocale();
  const pathname = usePathname();
  const t = useTranslations("common");

  return (
    <nav aria-label={t("language")}>
      <ul className="flex items-center gap-4 font-display text-sm font-medium">
        {routing.locales.map((code) => {
          const active = code === locale;
          return (
            <li key={code}>
              <Link
                href={pathname}
                locale={code}
                hrefLang={code}
                lang={code}
                aria-label={labels[code] ?? code}
                aria-current={active ? "true" : undefined}
                className={
                  active
                    ? "underline decoration-2 underline-offset-8"
                    : "text-muted hover:text-ink"
                }
              >
                {code.toUpperCase()}
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
