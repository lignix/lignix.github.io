import { defineRouting } from "next-intl/routing";

// To add a language: add its code here, create messages/<code>.json,
// and add its label in src/components/LanguageSwitcher.tsx.
export const routing = defineRouting({
  locales: ["en", "fr"],
  defaultLocale: "en",
});

export type Locale = (typeof routing.locales)[number];
