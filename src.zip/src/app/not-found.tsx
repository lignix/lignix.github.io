import type { Metadata } from "next";

export const metadata: Metadata = { title: "404 – Charles Bouvier" };

export default function NotFound() {
  return (
    <html lang="en">
      <body style={{ fontFamily: "system-ui, sans-serif", padding: "3rem 1.5rem" }}>
        <h1>404</h1>
        <p>Page not found / Page introuvable.</p>
        <p>
          <a href="/en/">English</a> · <a href="/fr/">Français</a>
        </p>
      </body>
    </html>
  );
}
