import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Charles Bouvier",
  robots: { index: false },
};

// Static export has no server redirect, so "/" picks a language in the browser.
const script = `
  var lang = (navigator.language || "en").toLowerCase().indexOf("fr") === 0 ? "fr" : "en";
  location.replace("/" + lang + "/" + location.hash);
`;

export default function RootPage() {
  return (
    <html lang="en">
      <head>
        <noscript>
          <meta httpEquiv="refresh" content="0;url=/en/" />
        </noscript>
        <script dangerouslySetInnerHTML={{ __html: script }} />
      </head>
      <body>
        <p>
          <a href="/en/">English</a> · <a href="/fr/">Français</a>
        </p>
      </body>
    </html>
  );
}
